/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singletonpattern;

/**
 *
 * @author Mert
 */
public class SingletonPattern {

    /**
     * @param args the comm3s2w3s2and line arguments
     */
    public static void main(String[] args) {
        SingletonClass object = SingletonClass.getInstance();
        
        System.out.println("ilk obje ilk değer = "+object.tampon);
        object.tampon++;
        System.out.println("ilk obje arttırılmış değer = "+object.tampon);
        
        SingletonClass object2=SingletonClass.getInstance();
        System.out.println("ikinci obje ilk değer = "+object2.tampon);
        object2.tampon++;
        System.out.println("ikinci obje arttırılmış değer = "+object2.tampon);
                
    }
    
}
