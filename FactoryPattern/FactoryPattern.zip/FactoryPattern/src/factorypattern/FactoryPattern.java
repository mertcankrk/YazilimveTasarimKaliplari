/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorypattern;

/**
 *
 * @author Mert
 */
public class FactoryPattern {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(" ");
         try{
         V8 V8 = (V8) MotorFactory.createMotor(V8.class);
            V8.Tip();
            V8.Hacim(6);
            V8.Piston(8);
            
             System.out.println(" ");
            
             Boxer boxer = (Boxer) MotorFactory.createMotor(Boxer.class);
             boxer.Tip();
             boxer.Hacim(2);
             boxer.Piston(6);
              }catch(Exception e){
            e.printStackTrace();
        }
    }
      public interface Motor{
        void Tip();
        void Hacim(float hacim);
        void Piston(int piston);
    }
      
          public static class MotorFactory {
    public static Motor createMotor(Class aClass) throws IllegalAccessException, InstantiationException {
            return (Motor) aClass.newInstance();
    }
}
          public static class V8 implements Motor{
        
        @Override
        public void Tip(){
            System.out.println("Motor V tipinde bir motordur.");
        }

        @Override
        public void Hacim(float hacim) {
            System.out.println(hacim+" litre hacmindedir.");
        }

        @Override
        public void Piston(int piston) {
            System.out.println(piston+" tane pistonu vardır.");
        }
        
        
    }
    
     public static class Boxer implements Motor{
        
        @Override
        public void Tip(){
            System.out.println("Motor boxer tipinde bir motordur.");
        }

        @Override
        public void Hacim(float hacim) {
            System.out.println(hacim+" litre hacmindedir.");
        }

        @Override
        public void Piston(int piston) {
            System.out.println(piston+" tane pistonu vardır.");
        }
        
        
    }
}
